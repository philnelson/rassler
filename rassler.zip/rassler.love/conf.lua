function love.conf(t)
	t.identity = "exfu_rassler"
	t.version = "0.10.2"
    t.window.width = 800
    t.window.height = 600
	t.window.title = "Rassler"
end